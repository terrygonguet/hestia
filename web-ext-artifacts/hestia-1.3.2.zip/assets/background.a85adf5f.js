import{h as n,s as t,p as r}from"./index.1f81830b.js";import{b as o}from"./vendor.c6f5c0c2.js";o.runtime.onInstalled.addListener(async function(a){const{reason:s,previousVersion:p}=a;switch(s){case"install":const e=t.map(i=>({name:i,time:new Date}));await r({migrations:e});break;case"update":await n();break}});
//# sourceMappingURL=background.a85adf5f.js.map
