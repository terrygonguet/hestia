import"./modulepreload-polyfill.b7f2da20.js";import{O as e}from"./GlobalStyles.b78e112a.js";/* empty css               */import"./vendor.c6f5c0c2.js";import"./index.1f81830b.js";var o;new e({target:(o=document.getElementById("app"))!=null?o:document.body});
//# sourceMappingURL=options.4cae3cda.js.map
