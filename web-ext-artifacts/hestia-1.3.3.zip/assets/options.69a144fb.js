import"./modulepreload-polyfill.b7f2da20.js";import{O as t}from"./GlobalStyles.2f327105.js";/* empty css               */import"./vendor.c6f5c0c2.js";import"./index.b968f37b.js";var o;new t({target:(o=document.getElementById("app"))!=null?o:document.body});
//# sourceMappingURL=options.69a144fb.js.map
