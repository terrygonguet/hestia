git clone https://github.com/terrygonguet/hestia.git
cd hestia
npm i
npm run build

Developed on Windows10 pro with node v8.9.0 and npm v6.1.0
Addon files are in hestia/dist/

3rd party libs : 
webextension-polyfill v0.2.1 : https://github.com/mozilla/webextension-polyfill
interactjs v1.3.4 : https://github.com/taye/interact.js
vue v2.5.16 : https://github.com/vuejs/vue
uuidv4 v1.0.1 : https://github.com/thenativeweb/uuidv4
fontawesome v1.1.8 : https://github.com/FortAwesome/Font-Awesome