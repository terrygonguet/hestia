# Living Room Tab
A customizable new tab extension. You can choose what links to show and how it looks with resizable categories and custom CSS (WIP).

# Build
`git clone https://github.com/terrygonguet/hestia.git`
`cd hestia`
`npm i`
`npm run build`

